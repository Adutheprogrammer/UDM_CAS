<?php require_once('../config.php') ?>
<!DOCTYPE html>
<html lang="en">
 <?php require_once('inc/header.php') ?>
<body class="hold-transition">
  <script>
    start_loader()
  </script>
  <style>
    html, body {
      height: 100% !important;
      width: 100% !important;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    body {
      background-image: url("<?php echo validate_image($_settings->info('cover')) ?>");
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      position: relative;
      overflow: hidden;
    }

    body::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image: inherit;
      background-size: inherit;
      background-position: inherit;
      background-repeat: inherit;
      filter: blur(5px) brightness(0.8);
      z-index: -1;
    }

    #login {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 1;
      padding: 15px;
      max-width: 100%;
    }

    #logo-img {
      height: 150px;
      width: 150px;
      object-fit: cover;
      border-radius: 50%;
      margin-bottom: 10px;
      border: 3px solid #6c5ce7; /* New border for logo */
    }

    .login-title {
      text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.6);
      color: #ffffff;
      font-size: 2.2rem;
      margin-bottom: 20px;
    }

    .card {
      width: 100%;
      max-width: 400px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
      background-color: #2d3436;  /* Darker gray background */
      border-radius: 10px; /* Rounded corners */
      overflow: hidden;
    }

    .card-header {
      background-color: #6c5ce7;  /* Purple color for header */
      color: white;
      text-align: center;
      font-weight: bold;
      padding: 15px;
      font-size: 1.2rem;
    }

    .card-body {
      padding: 30px;
    }

    .input-group-text {
      background-color: #0984e3;  /* Blue for input icons */
      color: white;
      border-radius: 0;
    }

    .form-control {
      background-color: #dfe6e9;  /* Light gray background for input fields */
      color: #2d3436; /* Dark text color */
      border-color: #6c5ce7;  /* Matching border color */
      border-radius: 0;
    }

    .form-control:focus {
      background-color: #ffffff;  /* White background on focus */
      border-color: #0984e3;  /* Focus border color */
    }

    .btn-primary {
      background-color: #6c5ce7;  /* Purple button */
      border-color: #6c5ce7;
      width: 100%;
      padding: 12px;
      font-size: 1rem;
    }

    .btn-primary:hover {
      background-color: #5a4db5;  /* Slightly darker purple on hover */
      border-color: #5a4db5;
    }

    a {
      color: #81ecec; /* Aqua text color */
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
      color: #00cec9; /* Brighter aqua */
    }
    b{
        font-size:45px;
    }
  </style>

  <div id="login">
    <div class="text-center">
      <img src="<?= validate_image($_settings->info('logo')) ?>" alt="Logo" id="logo-img">
      <h1 class="login-title"><b><?php echo $_settings->info('name') ?></b></h1>
    </div>
    <div class="card">
      <div class="card-header">
        <h4>Login</h4>
      </div>
      <div class="card-body">
        <form id="login-frm" action="" method="post">
          <div class="input-group mb-3">
            <input type="text" class="form-control" autofocus name="username" placeholder="Username">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" class="form-control" name="password" placeholder="Password">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-8">
              <a href="<?php echo base_url ?>">Return to Dashboard</a>
            </div>
            <div class="col-4">
              <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<script>
  $(document).ready(function(){
    end_loader();
  })
</script>

</body>
</html>
