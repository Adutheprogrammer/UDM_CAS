<style>
  /* User Avatar Image Style */
  .user-img {
    position: absolute;
    height: 30px;
    width: 30px;
    object-fit: cover;
    left: -8%;
    top: -12%;
    border-radius: 50%;
  }

  /* Rounded Button Style */
  .btn-rounded {
    border-radius: 50px;
    background-color: #003366; /* Dark Blue */
    color: white;
    border: none;
    padding: 12px 24px;
    transition: transform 0.3s ease-in-out, background-color 0.3s ease;
  }

  .btn-rounded:hover {
    background-color: #002244; /* Darker Blue */
    transform: scale(1.05);
  }

  /* Navbar Styles */
  #login-nav {
    position: fixed !important;
    top: 0 !important;
    z-index: 1037;
    padding: 1.5em 1.8em !important;
    background: linear-gradient(to right, #003366, #002244); /* Dark Blue Gradient */
    color: white;
    border-bottom: 2px solid #d1c6e5;
  }
  
  #top-Nav {
    top: 5em;
    background-color: #001a33; /* Dark Blue */
  }

  .text-sm .layout-navbar-fixed .wrapper .main-header ~ .content-wrapper,
  .layout-navbar-fixed .wrapper .main-header.text-sm ~ .content-wrapper {
    margin-top: calc(4) !important;
    padding-top: calc(6em) !important;
  }

  /* Left Side Panel for Burger Menu */
  .side-panel {
    position: fixed;
    top: 0;
    left: -270px;
    width: 270px;
    height: 100%;
    background-color: #021E34;
    z-index: 1040;
    transition: left 0.4s ease-in-out;
    padding-top: 60px;
  }

  .side-panel.open {
    left: 0;
  }

  .side-panel .nav-item {
    padding: 18px;
    color: #ecf0f1;
    font-size: 1.1em;
  }

  .side-panel .nav-link {
    color: #ecf0f1;
    text-decoration: none;
    transition: background-color 0.3s ease, transform 0.2s ease;
  }

  .side-panel .nav-link:hover {
    background-color: #005f8d; /* Lighter Blue */
    transform: translateX(10px);
  }

  /* Close Button */
  .close-panel {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 35px;
    color: white;
    cursor: pointer;
    z-index: 1060;
  }

  .close-panel:hover {
    color: #f39c12;
  }

  /* Burger Menu Icon */
.burger-menu {
  position: fixed;
  top: 25px;
  left: 1.2em;
  font-size: 35px;
  z-index: 1050;
  cursor: pointer;
  color: white; /* Change the color to black */
  transition: top 0.3s ease-in-out;
}

.burger-menu:hover {
  color: #16a085;
  transform: none; /* This removes any transformation */
}


.burger-menu span {
  display: block;
  width: 35px;
  height: 4px;
  margin: 7px 0;
  background-color: white; /* Set the background color of the burger icon lines to black */
  border-radius: 10px;
}


  .side-panel.open + .burger-menu {
    display: none;
  }

  /* Search Field */
  .search-field {
    position: absolute;
    top: 0;
    right: -100%;
    transition: right 0.4s ease-in-out;
    padding: 1.2em;
    background-color: #ffffff;
    z-index: 1040;
    border-radius: 10px;
  }

  .search-field.show {
    right: 0;
  }

  /* Custom Styling for Register, Student Login, and Admin Login */
.login-link {
  font-size: 1.4em;
  padding: .25em 0;
  color: #ffffff;
  border: none;
  width: 100%;
  text-align: center;
  text-transform: uppercase;
  font-weight: bold;
  background-color: #003366; /* Dark Blue */
  border-radius: 5px;
  transition: transform 0.3s ease, background-color 0.3s ease;
  margin-left: 7%; /* Move the button to the right */
}

.login-link:hover {
  background-color: #16a085; /* Darker Blue */
  transform: scale(1.1);
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
}

/* Refined style for the navbar itself */
#login-nav {
  background-color: #001a33; /* Dark Blue */
  padding-top: 0;
  padding-bottom: 0;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* Navbar Styling */
.navbar {
  background-color: #003366; /* Dark Blue */
  color: white;
}


  /* Hide the burger button */
  #burgerButton {
    display: none;
  }

  section {
    margin-top: 60px;
    text-align: center;
    padding: 25px;
    background-color: #ecf0f1;
    border-radius: 12px;
  }
</style>

<!-- Burger Menu Icon -->
<div class="burger-menu" id="burger-icon">
  <span></span>
  <span></span>
  <span></span>
</div>

<!-- Side Panel (Burger Menu) -->
<div class="side-panel" id="side-panel">
  <div class="close-panel" id="close-panel">&times;</div>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a href="./" class="nav-link <?= isset($page) && $page == 'home' ? "active" : "" ?>">Home</a>
    </li>
    <li class="nav-item">
      <a href="./?page=projects" class="nav-link <?= isset($page) && $page == 'projects' ? "active" : "" ?>">Projects</a>
    </li>
    <li class="nav-item">
      <a href="./?page=projects_per_department&id=3" class="nav-link <?= isset($page) && $page == 'projects_per_department' ? "active" : "" ?>">College of Arts and Science</a>
    </li>
    <li class="nav-item dropdown">
      <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle <?= isset($page) && $page == 'projects_per_curriculum' ? "active" : "" ?>">Courses</a>
      <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow" style="left: 0px; right: inherit;">
        <?php 
          $curriculums = $conn->query("SELECT * FROM curriculum_list where status = 1 order by name asc");
          $cI =  $curriculums->num_rows;
          while($row = $curriculums->fetch_assoc()):
            $cI--;
        ?>
        <li>
          <a href="./?page=projects_per_curriculum&id=<?= $row['id'] ?>" class="dropdown-item"><?= ucwords($row['name']) ?></a>
          <?php if($cI != 0): ?>
          <li class="dropdown-divider"></li>
          <?php endif; ?>
        </li>
        <?php endwhile; ?>
      </ul>
    </li>
    <li class="nav-item">
      <a href="./?page=about" class="nav-link <?= isset($page) && $page == 'about' ? "active" : "" ?>">About Us</a>
    </li>
    <?php if ($_settings->userdata('id') > 0): ?>
    <li class="nav-item">
      <a href="./?page=profile" class="nav-link <?= isset($page) && $page == 'profile' ? "active" : "" ?>">Profile</a>
    </li>
    <li class="nav-item">
      <a href="./?page=submit-archive" class="nav-link <?= isset($page) && $page == 'submit-archive' ? "active" : "" ?>">Submit Thesis/Capstone</a>
    </li>
    <?php endif; ?>
  </ul>
</div>

<!-- Navbar -->
<nav class="bg-navy w-100 position-fixed top-0" id="login-nav">
  <div class="d-flex justify-content-around w-100">
    <?php if ($_settings->userdata('id') > 0): ?>
      <span class="mx-2"><img src="<?= validate_image($_settings->userdata('avatar')) ?>" alt="User Avatar" id="student-img-avatar"></span>
      <span class="mx-2">Hello! <?= !empty($_settings->userdata('email')) ? $_settings->userdata('email') : $_settings->userdata('username') ?></span>
      <span class="mx-1"><a href="<?= base_url . 'classes/Login.php?f=student_logout' ?>"><i class="fa fa-power-off"></i></a></span>
    <?php else: ?>
      <a href="./register.php" class="login-link text-light">Register</a>
      <a href="./login.php" class="login-link text-light">Participant Login</a>
      <a href="./admin" class="login-link text-light">Admin login</a>
    <?php endif; ?>
  </div>
</nav>

<!-- Search Field -->
<div class="search-field" id="search-field">
  <input type="search" id="search-input" class="form-control rounded-0" required placeholder="Search..." value="<?= isset($_GET['q']) ? $_GET['q'] : '' ?>">
</div>

<script>
  $(function() {
    $('#search-form').submit(function(e) {
      e.preventDefault();
      if ($('[name="q"]').val().length == 0)
        location.href = './';
      else
        location.href = './?' + $(this).serialize();
    });

    $('#search_icon').click(function() {
      $('#search-field').addClass('show');
      $('#search-input').focus();
    });

    $('#search-input').focusout(function(e) {
      $('#search-field').removeClass('show');
    });

    $('#search-input').keydown(function(e) {
      if (e.which == 13) {
        location.href = "./?page=projects&q=" + encodeURI($(this).val());
      }
    });

    // Burger Menu Toggle
    $('#burger-icon').click(function() {
      $('#side-panel').toggleClass('open');
      if ($('#side-panel').hasClass('open')) {
        $('#burger-icon').fadeOut();
      } else {
        $('#burger-icon').fadeIn();
      }
    });

    // Close Panel Functionality
    $('#close-panel').click(function() {
      $('#side-panel').removeClass('open');
      $('#burger-icon').fadeIn(); 
    });
  });
</script>