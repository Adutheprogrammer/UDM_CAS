<?php require_once('./config.php') ?>
<!DOCTYPE html>
<html lang="en">
  <?php require_once('inc/header.php') ?>
  <body class="hold-transition">
    <script>
      start_loader();
    </script>

    <style>
      /* Base Styles */
      html, body {
        height: 100%;
        margin: 0;
        font-family: 'Arial', sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        background-image: url("<?php echo validate_image($_settings->info('cover')) ?>");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        font-size: 7.5px;
      }

      .login-container {
        background: linear-gradient(135deg, #2c3e50, #34495e); /* Darkish blue gradient for form */
        border-radius: 8px;
        padding: 40px 30px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        max-width: 400px;
        width: 100%;
        color: white; /* White text inside the form */
      }

      #logo-img {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        object-fit: cover;
        margin: 0 auto;
      }

      .login-title {
        text-align: center;
        font-size: 28px;
        font-weight: bold;
        margin-top: 20px;
        margin-bottom: 20px;
      }

      .form-group input {
        border-radius: 5px;
        padding: 12px;
        border: 1px solid #34495e; /* Dark border to match theme */
        margin-bottom: 20px;
        width: 100%;
        font-size: 16px;
        background-color: #34495e; /* Dark background for inputs */
        color: white; /* White text */
      }

      .form-group input:focus {
        border-color: #2980b9; /* Lighter blue border on focus */
        outline: none;
      }

      .btn-login {
        background-color: #2980b9; /* Blue button */
        color: white;
        border-radius: 5px;
        padding: 12px;
        width: 100%;
        font-size: 16px;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease;
      }

      .btn-login:hover {
        background-color: #3498db; /* Lighter blue on hover */
      }

      .text-center {
        text-align: center;
      }

      .text-muted {
        color: #ddd; /* Lighter muted text */
        font-size: 14px;
      }

      .alert {
        margin-top: 10px;
        padding: 10px;
        font-size: 14px;
      }

      .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
      }

      /* Responsive design */
      @media (max-width: 768px) {
        .login-container {
          padding: 30px 20px;
        }
      }
    </style>

    <?php if ($_settings->chk_flashdata('success')): ?>
      <script>
        alert_toast("<?php echo $_settings->flashdata('success') ?>", 'success')
      </script>
    <?php endif; ?>

    <div class="login-container">
      <div class="text-center">
        <img src="<?= validate_image($_settings->info('logo')) ?>" alt="Logo" id="logo-img">
        <h1 class="login-title"><?php echo $_settings->info('name') ?></h1>
      </div>

      <div>
        <div class="card-body">
          <form action="" id="slogin-form">
            <div class="form-group">
              <input type="email" name="email" id="email" placeholder="Email" required>
            </div>
            <div class="form-group">
              <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <div class="form-group text-center">
              <button type="submit" class="btn-login">Login</button>
            </div>
          </form>
          <div class="text-center">
            <p class="text-muted"><a href="<?php echo base_url ?>" style="color: #ddd;">Back to Dashboard</a></p>
          </div>
        </div>
      </div>
    </div>

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>
    <!-- Select2 -->
    <script src="<?php echo base_url ?>plugins/select2/js/select2.full.min.js"></script>

    <script>
      $(document).ready(function(){
        end_loader();

        // Registration Form Submit
        $('#slogin-form').submit(function(e){
          e.preventDefault();
          var _this = $(this);
          $(".pop-msg").remove();
          $('#password').removeClass("is-invalid");

          var el = $("<div>");
          el.addClass("alert pop-msg my-2").hide();

          start_loader();
          $.ajax({
            url: _base_url_ + "classes/Login.php?f=student_login",
            method: 'POST',
            data: _this.serialize(),
            dataType: 'json',
            error: function(err){
              console.log(err);
              el.text("An error occurred while saving the data");
              el.addClass("alert-danger");
              _this.prepend(el);
              el.show('slow');
              end_loader();
            },
            success: function(resp){
              if(resp.status == 'success'){
                location.href = "./";
              } else if(!!resp.msg){
                el.text(resp.msg);
                el.addClass("alert-danger");
                _this.prepend(el);
                el.show('show');
              } else {
                el.text("An error occurred while saving the data");
                el.addClass("alert-danger");
                _this.prepend(el);
                el.show('show');
              }
              end_loader();
              $('html, body').animate({scrollTop: 0}, 'fast');
            }
          });
        });
      });
    </script>
  </body>
</html>